const { performHash } = require('b')

module.exports = {
  action: () => {
    const input = Buffer.from('haay wuurl', 'utf8')
    return performHash(input)
  },
}
